<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'wifichat'))
    {
        echo 'Database Not Selected';
    }

    $adminpass = "123456";
    $pass = $_POST['pass'];

    if($pass != $adminpass)
    {
        echo 'Password Incorrect';
        header("refresh:2 url=wifichat.php");
    }
    else
    {
        echo 'Password Correct';
        session_start();
        $_SESSION['Admin'] = "Admin";
        header("refresh:2 url=wifichatadmin.php");
    }
?>