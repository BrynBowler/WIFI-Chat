<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="wifichatstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>
    <script type="text/javascript">

    <?php
        session_start();
        if(!isset($_SESSION['Access']))
        {
            header('location: wifichatcode.php');
        }
    ?>

        var name = "User #" + Math.ceil(Math.random() * 1000);
    	
    	// strip tags
    	name = name.replace(/(<([^>]+)>)/ig,"");
    	
    	// display name on page
    	$("#name-area").html("You are: <span>" + name + "</span>");
        
    	// kick off chat
        var chat =  new Chat();
    	$(function() {
    	
    		 chat.getState(); 
    		 
    		 // watch textarea for key presses
             $("#sendie").keydown(function(event) {  
             
                 var key = event.which;  
           
                 //all keys including return.  
                 if (key >= 33) {
                   
                     var maxLength = $(this).attr("maxlength");  
                     var length = this.value.length;  
                     
                     // don't allow new content if length is maxed out
                     if (length >= maxLength) {  
                         event.preventDefault();
                     }  
                  }  
             });
    		 // watch textarea for release of key press
    		 $('#sendie').keyup(function(e) {	
                
                //keycode 13 is Enter/Return Key
    			  if (e.keyCode == 13) { 
    			  
                    var text = $(this).val();
    				var maxLength = $(this).attr("maxlength");  
                    var length = text.length; 
                     
                    // send 
                    if (length <= maxLength + 1) { 
                     
    			        chat.send(text, name);	
    			        $(this).val("");
    			        
                    } else {
                    
    					$(this).val(text.substring(0, maxLength));
    					
    				}	
    				
    				
    			  }
             });
            
    	});
    </script>

</head>
    <body onload="setInterval('chat.update()', 200)">
        <section id="top">
            <div class="header">
                <img src="images/logo.png">
            </div>
            <div class="header">
                <h1>Welcome to WIFI Chat</h1>
            </div>

            <div class="header" 
            style="position: absolute;
               right: 1%;
               top: 10%;">
                <button id="adminlink" onclick="adminPassword()"><h2>Admin Tab</h2></button>
            </div>
        </section>

        <section id="middle">
            <div id="chat-wrap">
                <div id="chat-header">
                    <div id="name-area">

                    </div>
                </div>
                <div id="chat-area">

                </div>
            </div>
        </section>

        <section id="bottom">
            <div id="messageForm">
                <form id="send-message-area">
                    <textarea id="sendie" maxlength = '100' placeholder="Enter Your Message..." ></textarea>
                </form>
            </div>
            <br>
        </section>
        <script>
            // display name on page
            $("#name-area").html("You are: <span>" + name + "</span>");
        </script>

        <div id="overlay">
            <div id="adminPassword">

                <h1>Enter Admin Password</h1>
                <form id="adminPass" action="wifichatpass.php" method="post">
                    <div id="Pass">
                        <h4>Enter Password:</h4>
                            <input type="text" id="codebox" name="pass" maxlength="6" style="width: 45%">
                    </div>  
            <div id="adminSubmit">
                <input type="submit" value="Submit">
            </div>
            <div id="return">
                <a id="returntext" onclick="adminPasswordClose()">Return to WifiChat</a>
            </div>
        </div>

        

        <script>
            function adminPassword(){
                document.getElementById("overlay").style.display = "block";
            }

            function adminPasswordClose(){
                document.getElementById("overlay").style.display = "none";
            }
        </script>

    </body>
</html>