<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'wifichat'))
    {
        echo 'Database Not Selected';
    }

    $host = 'localhost:3308';
    $user = 'root';
    $pass = '';
    $db = 'wifichat';

    $mysqli = new mysqli($host,$user,$pass,$db);

    $codenumber = $mysqli->query
        ("SELECT code FROM admincode WHERE id = 1")
    or die($mysqli->error);

    $wifichat = $codenumber->fetch_assoc();

    $entry = $wifichat['code'];
    $code = $_POST['codeentry'];
    

    

    if($code != $entry)
    {
        echo 'Password Incorrect';
        header("refresh:2 url=wifichatcode.php");
    }
    else
    {
        echo 'Password Correct';
        session_start();
        $_SESSION['Access'] ="Access";
        header("refresh:2 url=wifichat.php");
    }
?>