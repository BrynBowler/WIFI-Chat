<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="wifichatstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

</head>

    <?php
        session_start();
        if(!isset($_SESSION['Admin']))
        {
            header('location: wifichatcode.php');
        }
    ?>

<body>
    <div id="admintab">
        <h1>Wifichat Admin Tab</h1>
            <div id="admintabDiv">
                <form id="codechange" action="wifichatinsert.php" method="post">
                    <div id="code">
                        <h4>Enter New Code:</h4>
                            <input type="text" id="codebox" name="code" maxlength="6">
                    </div>
            <div id="adminSubmit">
                <input type="submit" value="Submit">
            </div>
        </form>
        <div id="return">
                <a id="returntext" href="wifichat.php">Return to WifiChat</a>
            </div>
    </div>
</body>