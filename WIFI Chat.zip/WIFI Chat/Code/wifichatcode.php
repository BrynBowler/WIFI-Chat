<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="wifichatstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

</head>
<body>
    <div id="entrytab">
        <h1>WifiChat Code Entry</h1>
            <div id="admintabDiv">
                <h4>Enter Code to Access WifiChat</h4>
                <form id="codeentry" action="wifichatentry.php" method="post">
                    <div id="code">
                        <h4>Enter Code:</h4>
                            <input type="text" id="codebox" name="codeentry" maxlength="6">
                    </div>  
            <div id="adminSubmit">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>