<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'wifichat'))
    {
        echo 'Database Not Selected';
    }

    $code = $_POST['code'];

    $sql = "UPDATE admincode SET code = '$code' WHERE id = 1";

    if(!mysqli_query($con,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        echo 'Inserted';
    }

    header("refresh:2 url=wifichat.php");

?>